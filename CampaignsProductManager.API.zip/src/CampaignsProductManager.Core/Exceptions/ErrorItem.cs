﻿namespace CampaignsProductManager.Core.Exceptions
{
    public enum ErrorItem
    {
        // Invalid Request Body
        InvalidEntityStructure,

        // Server Errors
        InternalServerError,
    }
}